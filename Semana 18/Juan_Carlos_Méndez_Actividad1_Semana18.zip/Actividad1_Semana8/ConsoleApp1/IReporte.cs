    public interface IReporte
    {
        void Ejecutar(Alumno[] alumnos);
    }

   