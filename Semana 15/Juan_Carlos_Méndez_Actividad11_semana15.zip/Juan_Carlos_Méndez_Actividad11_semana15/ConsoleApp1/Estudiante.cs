﻿using System;
using System.Security.Cryptography.X509Certificates;
public class Estudiante
{
string nombre;
int edad;
string carrera;
string carnet;
int NotaAdmision;
public static void Main()
{
    Console.Write("Ingresar nombre: ");
    string nombre = Console.ReadLine();

    Console.Write("Ingresar edad");
    int edad = Convert.ToInt32(Console.ReadLine());

    Console.Write("Ingresar carrera: ");
    string carrera = Console.ReadLine();

    Console.Write("Ingresar carnet: ");
    string carnet = Console.ReadLine();

    Console.Write("Ingresar Nota Admisión");
    int NotaAdmision = Convert.ToInt32(Console.ReadLine());

Estudiante estudiante = new Estudiante(nombre, edad, carrera, carnet, NotaAdmision);

estudiante.show();

Console.WriteLine("¿Puede matricularse? "+ (estudiante.PuedeMatricular() ? "Si" : "No"));
}
    Estudiante(string nombre, int edad, string carrera, string carnet, int NotaAdmision) {
this.nombre = nombre;
this.edad = edad;
this.carrera = carrera;
this.carnet = carnet;
this.NotaAdmision = NotaAdmision;
}
public void show() 
{
Console.WriteLine(this.nombre);
Console.WriteLine(this.edad);
Console.WriteLine(this.carrera);
Console.WriteLine(this.carnet);
Console.WriteLine(this.NotaAdmision);
}
public bool PuedeMatricular()
{
    return this.NotaAdmision >= 75 && this.carnet.EndsWith("2025");
}
}